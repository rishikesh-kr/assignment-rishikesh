to run tomcat as systemd service a asystemd template file has been created which is in files folder 
file name is tomcat.service  
